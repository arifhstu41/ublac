<?php

# Version 2.3.0
$lang['menu_builder']        = 'Menu Setup';
$lang['all_branches']           = 'All branches';
$lang['new_branches']           = 'New branch';
$lang['company_name']           = 'Comapny Name';
$lang['branch_active_module']           = 'branch settings';

