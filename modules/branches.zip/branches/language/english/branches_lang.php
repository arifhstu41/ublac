<?php

# Version 2.3.0
$lang['branches_branch']        = 'Branch Name';
$lang['branches_prefix']           = 'Invoice Prefix';
$lang['branches_postfix']           = 'Invoice Postfix';
$lang['task_single_user']           = 'Users';
$lang['branches_user']           = 'Users';
$lang['branches_logo']           = 'Logo';
$lang['branches_general_logo']           = 'Logo';
$lang['new_branches']           = 'New Branches';
$lang['invoice_branches_id']           = 'Branch';
$lang['invoice_branch']           = 'Branch';
$lang['branch_street']           = 'Street';
$lang['branch_city']           = 'City';
$lang['branch_state']           = 'State';
$lang['branch_zip']           = 'Zip';
$lang['branch_country']           = 'Country';
$lang['estimate_prefix']           = 'Estimate Prefix';
$lang['estimate_postfix']           = 'Estimate Postfix';
$lang['estimate_branch']           = 'Branch';
